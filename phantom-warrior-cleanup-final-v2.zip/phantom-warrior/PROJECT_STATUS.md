# Project Status — PHANTOM WARRIOR (singular)

**Current batch:** Final wording fix — complete. Cleanup phase is COMPLETE. The website as a whole is NOT finished.
**Next batch:** THEME FOUNDATION ONLY — see `docs/NEXT_BATCH.md`. Not started.

## Rules (mandatory)
HTML5, CSS3, vanilla JS only. No React, TypeScript, Node, npm, frameworks, or build tools. Must work by opening `index.html`.

## Brand
Near-black #050608, charcoal #111318, silver #D5D8DE, crimson #FF1738, electric blue #3BAEFF (sparingly). Tagline: PLAY. FIGHT. WIN. Tokens live in `:root` of `assets/css/style.css`. Theme unchanged.

## Done
- 1A foundation; 1B homepage; Batch 2 homepage cleanup (Teams/Maps/Plan My Maps removed from nav, Team Preview and statistics removed)
- Final cleanup & logo consistency, see below
- Final wording fix: Maps Explorer card text changed from "Explore seven Free Fire maps." to "Explore maps and learn the terrain." No other homepage wording needed changing (remaining words like "game", "battle", "compete" are generic brand copy tied to the tagline). Nothing else was touched.

## Final cleanup changes (made in the previous batch)
- **Sign Up restored.** Public nav and footer on all 7 pages: Home, About, Contact, Login, Sign Up. Login and Sign Up now use the same plain link style (the red `nav-cta` style is no longer used on any page; the CSS rule is kept).
- **No separate Sign Up page exists** in the project. Sign Up links to the existing entry point `login.html#signup`, a placeholder block already on the Login page. No authentication, sessions or password storage were added.
- **One logo only:** `assets/images/logo/pw-primary-logo.png` (verified: valid PNG, 500x500, RGBA, shows the red/silver PW mark). All displayed logos on all pages (header, footer, homepage hero, homepage About panel) use it. `pw-emblem.svg` is no longer referenced anywhere; the file is kept in `assets/images/logo/` unused.
- **Proportions fixed:** the logo is square, but it had been displayed at 30x36, 44x53 and 200x240 (distorted). Now 36x36 (header), 48x48 (footer), 200x200 (hero), with `height:auto`/`object-fit:contain` in CSS.
- **Homepage:** removed the "Team & Community" card (it promoted the deferred Teams area). Maps Explorer and Plan My Maps remain as non-clickable "Members · Upcoming" cards; the two remaining cards use a new `.grid-2` layout so they fill the row.
- **Login page:** removed one stray `</div>` that closed the container early (markup fix only; text unchanged).
- Already done in Batch 2 and kept: no "Free Fire Esports" on the homepage, no team-role cards, no statistics, Teams absent from nav and footer.
- NOT touched: `teams.html`, `maps.html`, `plan-maps.html`, JavaScript, colour theme, About/Contact/Login text.

## Tested (static checks only; no browser available)
See the report delivered with this batch. Summary: logo path, nav/footer link sets, link targets, asset paths, homepage text searches, JS syntax and tag balance were all checked by script. Visual rendering was not checked in a browser.

## Known limits / open items
- **Protected pages are not actually protected.** `maps.html` and `plan-maps.html` (and `teams.html`) are reachable by typing the URL. No login exists, so they cannot be gated yet. They are not linked from any public page.
- Sign Up has no page of its own; it is a placeholder section on `login.html`.
- Inner pages still say "Free Fire" in their own subtitles/meta (e.g. About, Maps). Left to preserve page content. The homepage no longer mentions Free Fire anywhere.
- `pw-emblem.svg` is unused but still in the folder.
- Display font is the system `Impact` stack.

## Conventions
- Header/footer markup is duplicated in all 7 pages; update all when changing nav
- Logo: always `assets/images/logo/pw-primary-logo.png`, square (1:1); never set a non-square width/height
- Footer social links: set URLs in `assets/js/config.js`
