# Next Batch — THEME FOUNDATION ONLY

Status: not started. The cleanup phase (homepage cleanup, Sign Up restore, single-logo consistency, final wording fix) is complete.

Scope: establish the theme foundation only (design tokens, typography, spacing, buttons, panels, shared header/footer styling) in the existing CSS files. HTML, CSS and vanilla JS only. Do not begin responsive redesign or new sections.

Out of scope: authentication, maps, Plan My Maps, strategy editor, Teams.

Reminders:
- Public nav/footer: Home, About, Contact, Login, Sign Up (Login and Sign Up styled consistently).
- Sign Up points to `login.html#signup` (no separate page yet).
- Use only `assets/images/logo/pw-primary-logo.png`, kept square.
- `teams.html`, `maps.html`, `plan-maps.html` exist but are unlinked and not access-protected until authentication is built.
- Before finishing: check links/paths, update `PROJECT_STATUS.md`, ship the full project ZIP.
