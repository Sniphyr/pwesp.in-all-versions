// PHANTOM WARRIOR — mobile menu + active page highlight
(function () {
  var toggle = document.querySelector(".nav-toggle");
  var list = document.getElementById("nav-list");
  function close() { list.classList.remove("open"); toggle.setAttribute("aria-expanded", "false"); }
  if (toggle && list) {
    toggle.addEventListener("click", function () {
      var open = list.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    list.addEventListener("click", function (e) { if (e.target.closest("a")) close(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") { close(); toggle.focus(); } });
    window.addEventListener("resize", function () { if (window.innerWidth > 1060) close(); });
  }
  var page = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-list a").forEach(function (a) {
    if (a.getAttribute("href") === page) a.setAttribute("aria-current", "page");
  });
})();
