# Asset Guide
- **Logo:** `assets/images/logo/pw-primary-logo.png` (500x500, transparent PNG) is the only logo displayed. Keep it square; never stretch it. `pw-emblem.svg` is an unused leftover placeholder and must not be displayed.
- **Hero background:** the hero is CSS-only. To use artwork, save it as `assets/images/backgrounds/hero.webp` (about 1920px wide, under 300 KB) and add it to `.hero` in `components.css`, keeping the red glow gradient on top.
- `assets/images/maps/` — Free Fire map images (for the Maps batch)
- `assets/icons/` — small SVG icons

Naming: lowercase, hyphens, no spaces.
