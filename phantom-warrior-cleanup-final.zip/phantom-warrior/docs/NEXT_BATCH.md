# Next Batch — THEME FOUNDATION ONLY

Status: not started. The final cleanup batch is complete.

Scope: establish the theme foundation only (design tokens, typography, spacing, buttons, panels, shared header/footer styling) in the existing CSS files. HTML, CSS and vanilla JS only.

Out of scope: authentication, maps, Plan My Maps, strategy editor, Teams, new homepage sections.

Reminders:
- Public nav/footer: Home, About, Contact, Login, Sign Up. Keep Login and Sign Up visually consistent.
- Sign Up currently points to `login.html#signup` (no separate page). Decide later whether it gets its own page.
- Use only `assets/images/logo/pw-primary-logo.png`, keeping it square.
- `teams.html`, `maps.html`, `plan-maps.html` exist but are unlinked and not yet access-protected; protection needs the future authentication batch.
- Before finishing: check links/paths, update `PROJECT_STATUS.md`, ship the full project ZIP.
