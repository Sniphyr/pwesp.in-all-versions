# Project Status — PHANTOM WARRIOR (singular)

**Current batch:** Batch 2 — Theme foundation + responsive design — complete. The website as a whole is NOT finished.
**Next batch:** HOMEPAGE CINEMATIC REDESIGN — see `docs/NEXT_BATCH.md`. Not started.

## Rules (mandatory)
HTML5, CSS3, vanilla JS only. No React, TypeScript, Node, npm, frameworks, or build tools. Must work by opening `index.html`.

## Brand
Near-black #050608, charcoal #111318, silver #D5D8DE, crimson #FF1738, electric blue #3BAEFF (sparingly). Tagline: PLAY. FIGHT. WIN. Tokens live in `:root` of `assets/css/style.css`.

## Done
- 1A foundation; 1B homepage; Batch 2 homepage cleanup (Teams/Maps/Plan My Maps removed from nav, Team Preview and statistics removed)
- Final cleanup & logo consistency, see below
- Final wording fix: Maps Explorer card text changed from "Explore seven Free Fire maps." to "Explore maps and learn the terrain." No other homepage wording needed changing (remaining words like "game", "battle", "compete" are generic brand copy tied to the tagline). Nothing else was touched.

## Batch 2: Theme foundation + responsive design (this batch)

### What changed
- **Design tokens** (`style.css` `:root`): backgrounds, text, accents (with `--red-rgb`/`--blue-rgb` triplets so `rgba(var(--red-rgb),.2)` follows theme changes), gradients, fluid type scale, spacing scale, fluid gutter/section padding, radii, cut-corner size, shadows, transitions, z-index. Old variable names kept as-is. Components use tokens instead of raw colours.
- **Theme consistency:** nav + active link, headings, primary/ghost buttons, panels, page heads, placeholders, footer, and new shared form styles (`input`, `select`, `textarea`, `.field`, visible focus, 16px text, 44px min height). No forms exist yet; styles are ready for later batches.
- **Glow reduced** (hero emblem, sparks, button hover, panel hover) to match the restrained brief. Dead outer glows that `clip-path` was already hiding were removed.
- **Logo:** only `assets/images/logo/pw-primary-logo.png` is displayed (header, footer, hero, About panel). Square 1:1 everywhere. `width`/`height` attributes added to the About panel logo. `pw-emblem.svg` is kept but unreferenced.
- **Mobile menu:** now collapses at 820px (was 1060px, which put laptops at 1024px into a hamburger). Closes on Escape (focus returns to the button), outside click, link click and resize past breakpoint. `aria-expanded` and `aria-controls` kept in sync. Without JavaScript the nav stays visible and wraps.
- **Accessibility fixes:** `clip-path` clipped focus outlines on buttons, so buttons now draw the focus ring inside the shape. Button gradient darkened so white text is at least 5:1 (was 3.87:1 at the top). Touch targets (nav links, toggle, buttons, footer links) are at least 44px high. `scroll-padding-top` added so `#signup` is not hidden under the sticky header.
- Removed six inline `font-size` styles on inner-page `<h1>`s; they now use `--fs-h1-page` via `.page-head h1`.

### Files modified
`assets/css/style.css`, `assets/css/components.css`, `assets/css/responsive.css`, `assets/js/navigation.js`, `index.html` (logo size attributes), `about.html`, `contact.html`, `login.html`, `maps.html`, `plan-maps.html`, `teams.html` (inline h1 style removed), `PROJECT_STATUS.md`, `docs/NEXT_BATCH.md`.
Not modified: `main.js`, `config.js`, page content/wording, assets.

### Responsive improvements
Breakpoints: 1060 (5-col grid), 820 (mobile menu), 860 (hero/split stack, 4/5-col grids to 2), 640 (2/3-col grids to 1, footer stacks), 480, 374 (small mobile), plus short-landscape hero. Fluid gutters, section padding, panel padding and headings (`clamp`). Hero uses `100svh` with a `vh` fallback. `min-width:0` on grid/flex children prevents overflow. Container widens to 1280px at 1440px and above.

### Tests actually performed
Real Chromium (Playwright) against `file://` pages:
- All 7 pages at 320, 360, 375, 414, 600, 768, 900, 1024, 1440 and 1920px: no horizontal scroll (`scrollWidth == clientWidth`) and no element extending past the viewport (the off-screen skip link was excluded on purpose). No page errors or failed requests.
- Every `<img>` loaded, uses the PNG path and renders square.
- Menu at 320, 375, 768, 820, 821 and 1024px: toggle visibility, open, `aria-expanded`, Escape, focus return, outside click, link navigation, active-link `aria-current`, close on resize. All behaved correctly.
- Reduced motion (emulated): animations none, no sparks created, reveal content visible. Keyboard Tab shows a 2px outline on the focused toggle.
- Computed contrast ratios for the main colour pairs (all >= 4.8:1 after the button fix).
- Screenshots viewed at 320 (closed and open menu) and 1440 on the homepage. Screenshots of 375, 768 and login were captured but not viewed.
Static: local `href`/`src` paths and `#` anchors checked by script (none broken); CSS searched for fixed pixel widths (none found).

### Known limits
- `Impact` is not installed in the test browser, so headings were checked with the fallback font. Real Impact is narrower; wrapping should be equal or better but was not seen.
- Only Chromium was tested. Safari/Firefox and real devices were not.
- Not tested: forms (none exist), screen readers, 200% browser zoom.
- Visual polish was judged from a few screenshots only; the full cinematic look is the next batch.
- Header/footer markup is still duplicated across 7 pages.
- Protected pages are still not protected (no auth exists). `teams.html`, `maps.html`, `plan-maps.html` remain unlinked.
- Inner pages still say "Free Fire" in subtitles/meta (content left as-is).

## Final cleanup changes (previous batch) (made in the previous batch)
- **Sign Up restored.** Public nav and footer on all 7 pages: Home, About, Contact, Login, Sign Up. Login and Sign Up now use the same plain link style (the red `nav-cta` style is no longer used on any page; the CSS rule is kept).
- **No separate Sign Up page exists** in the project. Sign Up links to the existing entry point `login.html#signup`, a placeholder block already on the Login page. No authentication, sessions or password storage were added.
- **One logo only:** `assets/images/logo/pw-primary-logo.png` (verified: valid PNG, 500x500, RGBA, shows the red/silver PW mark). All displayed logos on all pages (header, footer, homepage hero, homepage About panel) use it. `pw-emblem.svg` is no longer referenced anywhere; the file is kept in `assets/images/logo/` unused.
- **Proportions fixed:** the logo is square, but it had been displayed at 30x36, 44x53 and 200x240 (distorted). Now 36x36 (header), 48x48 (footer), 200x200 (hero), with `height:auto`/`object-fit:contain` in CSS.
- **Homepage:** removed the "Team & Community" card (it promoted the deferred Teams area). Maps Explorer and Plan My Maps remain as non-clickable "Members · Upcoming" cards; the two remaining cards use a new `.grid-2` layout so they fill the row.
- **Login page:** removed one stray `</div>` that closed the container early (markup fix only; text unchanged).
- Already done in Batch 2 and kept: no "Free Fire Esports" on the homepage, no team-role cards, no statistics, Teams absent from nav and footer.
- NOT touched: `teams.html`, `maps.html`, `plan-maps.html`, JavaScript, colour theme, About/Contact/Login text.

## Tested in the previous batch
Static checks only (no browser). Browser tests for this batch are listed above.

## Known limits / open items
- **Protected pages are not actually protected.** `maps.html` and `plan-maps.html` (and `teams.html`) are reachable by typing the URL. No login exists, so they cannot be gated yet. They are not linked from any public page.
- Sign Up has no page of its own; it is a placeholder section on `login.html`.
- Inner pages still say "Free Fire" in their own subtitles/meta (e.g. About, Maps). Left to preserve page content. The homepage no longer mentions Free Fire anywhere.
- `pw-emblem.svg` is unused but still in the folder.
- Display font is the system `Impact` stack.

## Conventions
- Header/footer markup is duplicated in all 7 pages; update all when changing nav
- Logo: always `assets/images/logo/pw-primary-logo.png`, square (1:1); never set a non-square width/height
- Footer social links: set URLs in `assets/js/config.js`
