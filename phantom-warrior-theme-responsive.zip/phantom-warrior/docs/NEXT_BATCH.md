# Next Batch — HOMEPAGE CINEMATIC REDESIGN

Status: not started. Batch 2 (theme foundation + responsive design) is complete.

Scope: redesign the homepage (`index.html`) with cinematic sections, building on the existing tokens in `assets/css/style.css` and the components in `components.css`. HTML, CSS and vanilla JS only.

Out of scope: authentication, Supabase, map viewer, Plan My Maps editor, Teams activation.

Reminders:
- Change colours/theme through the `:root` variables, not raw values.
- Keep every new section responsive from 320px up (breakpoints in `responsive.css`; mobile menu at 820px, mirrored in `navigation.js`).
- Respect `prefers-reduced-motion`; keep focus outlines visible (buttons/panels use `clip-path`, which clips outlines, so draw focus inside the shape).
- Use only `assets/images/logo/pw-primary-logo.png`, kept square.
- No fake statistics, achievements or invented content.
- Public nav/footer: Home, About, Contact, Login, Sign Up (`login.html#signup`).
- `teams.html`, `maps.html`, `plan-maps.html` exist but are unlinked and not access-protected.
- Test in a real browser at 320, 375, 768, 1024 and 1440px; install or load a real display font if possible.
- Before finishing: check links/paths, update `PROJECT_STATUS.md`, ship the full project ZIP.
