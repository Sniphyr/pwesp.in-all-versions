# Project Status — PHANTOM WARRIOR (singular)

**Current batch:** 2 (homepage cleanup) — complete. The website as a whole is NOT finished.
**Next batch:** THEME FOUNDATION ONLY — see `docs/NEXT_BATCH.md`. Not started.

## Rules (mandatory)
HTML5, CSS3, vanilla JS only. No React, TypeScript, Node, npm, frameworks, or build tools. Must work by opening `index.html`.

## Brand
Near-black #050608, charcoal #111318, silver #D5D8DE, crimson #FF1738, electric blue #3BAEFF (sparingly). Tagline: PLAY. FIGHT. WIN. Tokens live in `:root` of `assets/css/style.css`. Theme unchanged in this batch.

## Done
- 1A: 7 pages, shared CSS/JS, nav/footer structure
- 1B: homepage visual upgrade, mobile menu, scroll reveals, reduced-motion support
- 2 (cleanup): see "Batch 2 changes" below

## Batch 2 changes (actually made)
- Public navbar on all 7 pages is now only: Home, About, Contact, Login.
- Footer link list on all 7 pages reduced to the same four links.
- Removed Teams, Maps, Plan My Maps and Sign Up from the navbar and footer links.
- Homepage title is now `PHANTOM WARRIOR`; meta description is `PHANTOM WARRIOR — Play. Fight. Win.`
- Homepage: removed the "FREE FIRE ESPORTS" hero tag, the "Explore Maps" / "Meet the Team" hero buttons, the Team Preview section (5 role cards), and the Highlights/statistics section.
- Homepage About paragraph no longer says "Free Fire esports organization" (now "an organization").
- Footer brand line on all 7 pages is now `PHANTOM WARRIOR. Play. Fight. Win.`
- Brand name checked everywhere: no plural "Warriors" found (it was already singular in the 1B files).
- NOT touched: `teams.html`, `maps.html`, `plan-maps.html` (kept, still reachable only by direct URL), all CSS, all JS, logo files, folder structure, About/Contact/Login page body content.

## Tested (static checks only; no browser was available)
- Searched `index.html` for `Free Fire Esports`, team/role/statistics markup and Teams/Maps/Sign Up links: none remain. One case-insensitive hit for "Free Fire" remains in the Maps Explorer feature card (see below).
- Nav and footer hrefs on all 7 pages point only to index/about/contact/login; all four files exist.
- All `src`/`href` asset references in all pages resolve to existing files.
- `index.html` section/div/ul/main tags balance; all 3 JS files pass `node --check`.
- Not tested: visual rendering and mobile menu in a real browser. Please open `index.html` and check.

## Known limits / open items
- Homepage "Tools built for players" section (Features) still has "Maps Explorer" and "Plan My Maps" cards marked Upcoming. They are not links and were not on the removal list; decide whether to remove them.
- Inner pages still contain "Free Fire" in their own content and meta descriptions (e.g. About subtitle "…in Free Fire esports.", Maps "Free Fire map library."). Left alone to preserve existing page content; the exact phrase was only required off the homepage and footer.
- Header logo is inconsistent: `about.html`, `maps.html`, `teams.html` use `pw-emblem.svg` (placeholder); the other pages use `pw-primary-logo.png`. Not changed (logo files preserved).
- `login.html` contains a "Sign up" placeholder block (`#signup`) and a pre-existing stray `</div>`. Left as-is; nothing links to it now.
- CSS for removed components (`.role`, `.avatar`, `.stat`, `.grid-4/.grid-5`, `.nav-cta`, `.note`) is kept for future use.
- No authentication, maps, strategies or player data exist. Display font is the system `Impact` stack.

## Conventions
- Header/footer markup is duplicated in all 7 pages; update all when changing nav
- New homepage sections: add a `<section>` in `index.html` using `.section`, `.section-head`, `.panel`, `.reveal`
- Footer social links: set URLs in `assets/js/config.js`
