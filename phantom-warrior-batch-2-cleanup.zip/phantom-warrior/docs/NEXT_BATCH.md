# Next Batch — THEME FOUNDATION ONLY

Status: not started. Batch 2 (homepage cleanup) is complete.

Scope for the next batch:
1. Establish the theme foundation only: design tokens, typography, spacing, buttons, panels, shared header/footer styling, in the existing CSS files.
2. Keep HTML/CSS/vanilla JS only.

Out of scope (do not build yet): authentication, maps, Plan My Maps, strategies, team rosters, new homepage sections.

Decisions to confirm before or during that batch:
- Remove or keep the "Maps Explorer" / "Plan My Maps" cards on the homepage Features section.
- Unify the header logo (some pages use `pw-emblem.svg`, others `pw-primary-logo.png`); see `docs/ASSET_GUIDE.md`.
- Whether Login should get a nav-CTA style now that Sign Up is gone.

Reminders: `teams.html`, `maps.html`, `plan-maps.html` exist but are not in the public nav. Before finishing any batch: check links/paths, update `PROJECT_STATUS.md`, and ship the full project ZIP.
