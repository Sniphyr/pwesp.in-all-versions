// PHANTOM WARRIOR — mobile menu + active page highlight
(function () {
  var toggle = document.querySelector(".nav-toggle");
  var list = document.getElementById("nav-list");
  var mq = window.matchMedia("(min-width: 821px)"); // keep in sync with responsive.css

  if (toggle && list) {
    function isOpen() { return list.classList.contains("open"); }
    function setOpen(open) {
      list.classList.toggle("open", open);
      toggle.setAttribute("aria-expanded", String(open));
    }
    toggle.addEventListener("click", function () { setOpen(!isOpen()); });
    list.addEventListener("click", function (e) { if (e.target.closest("a")) setOpen(false); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && isOpen()) { setOpen(false); toggle.focus(); }
    });
    document.addEventListener("click", function (e) {
      if (isOpen() && !e.target.closest(".nav")) setOpen(false);
    });
    var onChange = function (e) { if (e.matches) setOpen(false); };
    if (mq.addEventListener) mq.addEventListener("change", onChange); else mq.addListener(onChange);
  }

  var page = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-list a").forEach(function (a) {
    if (a.getAttribute("href") === page) a.setAttribute("aria-current", "page");
  });
})();
