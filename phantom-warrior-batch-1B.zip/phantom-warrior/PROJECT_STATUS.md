# Project Status — PHANTOM WARRIOR (singular)

**Current batch:** 1B (homepage visual upgrade) — complete. The website as a whole is NOT finished.
**Next batch:** see `docs/NEXT_BATCH.md`

## Rules (mandatory)
HTML5, CSS3, vanilla JS only. No React, TypeScript, Node, npm, frameworks, or build tools. Must work by opening `index.html`.

## Brand
Near-black #050608, charcoal #111318, silver #D5D8DE, crimson #FF1738, electric blue #3BAEFF (sparingly). Tagline: PLAY. FIGHT. WIN. Tokens live in `:root` of `assets/css/style.css`.

## Done
- 1A: 7 pages, shared CSS/JS, nav/footer structure
- 1B: homepage with hero, About, Features, Competitive identity, Team roles, Highlights; new nav (adds Plan My Maps, Sign Up) and footer on all 7 pages; mobile menu; scroll reveals; reduced-motion support; name corrected to PHANTOM WARRIOR

## Known limits
- The user's PW logo and welcome artwork were NOT in the working files. `assets/images/logo/pw-emblem.svg` is a placeholder emblem I drew; it is not the real logo. The hero background is pure CSS (rocks, smoke, sparks, red glow).
- Role cards are examples. No player names, wins or stats exist.
- Sign Up links to `login.html#signup` (placeholder). No authentication.
- Display font is the system `Impact` stack; it falls back to a plain sans where Impact is missing.
- Maps, Plan My Maps, Teams, About, Contact, Login pages are still placeholders.

## Conventions
- Header/footer markup is duplicated in all 7 pages; update all when changing nav
- New homepage sections: add a `<section>` in `index.html` using `.section`, `.section-head`, `.panel`, `.reveal`
- Footer social links: set URLs in `assets/js/config.js`
