# PHANTOM WARRIOR — Free Fire esports website

Static site: HTML5, CSS3, vanilla JavaScript only. No build step.

## Open it
Unzip, then open `index.html` in a browser.

## Structure
- 7 pages in the root: index, about, teams, maps, plan-maps, contact, login
- `assets/css/` style (tokens, base), components, responsive
- `assets/js/` config (name, social links), navigation (menu), main (reveals, footer, sparks)
- `docs/` roadmap, asset guide, next-batch brief

## Images
The emblem is a placeholder SVG. See `docs/ASSET_GUIDE.md` to swap in the real logo and artwork.

## Status
See `PROJECT_STATUS.md`.
