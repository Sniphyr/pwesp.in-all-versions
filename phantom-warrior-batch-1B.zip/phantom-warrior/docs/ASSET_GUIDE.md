# Asset Guide
The user's real PW logo and welcome artwork were not available and are not included.

- **Logo:** replace `assets/images/logo/pw-emblem.svg` with the real logo using the same filename (or change the `src` in the 7 headers/footers and `index.html`). Transparent PNG/SVG works best.
- **Hero background:** the hero is CSS-only. To use artwork, save it as `assets/images/backgrounds/hero.webp` (about 1920px wide, under 300 KB) and add `background-image:url(../images/backgrounds/hero.webp)` to `.hero` in `components.css`. Keep the red glow gradient on top.
- `assets/images/maps/` — Free Fire map images (for the Maps batch)
- `assets/icons/` — small SVG icons

Naming: lowercase, hyphens, no spaces.
