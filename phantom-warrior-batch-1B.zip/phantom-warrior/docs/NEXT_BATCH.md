# Next Batch — 1C (suggested)

1. Add the real logo and artwork per `ASSET_GUIDE.md`; wire the hero background if supplied.
2. Build About and Teams content (no invented players or results).
3. Then Maps library, Plan My Maps editor, and Login/Sign Up in later batches.

Do not build map viewer, editor, database or authentication until requested.
Before finishing: check links/paths, update `PROJECT_STATUS.md`, and ship `phantom-warrior-batch-1C.zip`.
