// PHANTOM WARRIOR — public Supabase client configuration.
// Fill in the two values below from Supabase Dashboard -> Project Settings -> API (see docs/SUPABASE_SETUP.md).
// ONLY the project URL and the publishable (or legacy "anon") key belong here. They are designed to be public.
// NEVER put a service_role / secret key in this file or anywhere in the website.
window.PW_SUPABASE = {
  url: "YOUR_SUPABASE_PROJECT_URL",        // e.g. https://abcdefghijklmnop.supabase.co
  publishableKey: "YOUR_SUPABASE_PUBLISHABLE_KEY", // publishable key (sb_publishable_...) or legacy anon key
  // Keep false until Google is enabled in Supabase (Authentication -> Providers -> Google) and tested.
  googleEnabled: false
};
