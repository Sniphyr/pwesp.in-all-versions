# Asset Guide
Reference images were not available in Batch 1A and have not been imported.

Place the two Phantom Warriors reference images here:
- `assets/images/logo/` — logo/emblem files (PNG with transparency or SVG preferred)
- `assets/images/backgrounds/` — artwork used as hero/section backgrounds

Other folders:
- `assets/images/maps/` — Free Fire map images
- `assets/icons/` — small UI icons (SVG preferred)

Naming: lowercase, hyphens, no spaces (e.g. `phantom-warriors-logo.png`).
Keep web images under ~500 KB each where possible.
