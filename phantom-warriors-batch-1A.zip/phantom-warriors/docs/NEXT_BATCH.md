# Next Batch — 1B (Homepage and branding)

Goal: turn the minimal hero into a complete, cinematic homepage.

Tasks
1. Add the two reference images per `ASSET_GUIDE.md`; use them in the hero/logo (only if present).
2. Build homepage sections: hero, about teaser, teams teaser, maps teaser, call to action.
3. Add a logo to the nav and footer on all 7 pages.
4. Refine the cinematic look (silver metal, crimson, restrained blue glow).
5. Keep it responsive; respect `prefers-reduced-motion`.

Do not build: map editor, login logic, or full content for other pages.

Before finishing: verify links and asset paths, update `PROJECT_STATUS.md`, and produce `phantom-warriors-batch-1B.zip`.
