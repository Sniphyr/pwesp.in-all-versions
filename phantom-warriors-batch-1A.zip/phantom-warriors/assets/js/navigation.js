// PHANTOM WARRIORS — mobile menu toggle + active page highlight
(function () {
  var toggle = document.querySelector(".nav-toggle");
  var list = document.getElementById("nav-list");
  if (toggle && list) {
    toggle.addEventListener("click", function () {
      var open = list.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open);
    });
  }
  var page = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-list a").forEach(function (a) {
    if (a.getAttribute("href") === page) a.setAttribute("aria-current", "page");
  });
})();
