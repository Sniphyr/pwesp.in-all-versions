// PHANTOM WARRIORS — shared page setup
(function () {
  var cfg = window.PW_CONFIG || {};
  var year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();
  var name = document.getElementById("footer-name");
  if (name && cfg.name) name.textContent = cfg.name;
})();
