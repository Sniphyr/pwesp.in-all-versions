// PHANTOM WARRIORS — site configuration (edit here, not in pages)
window.PW_CONFIG = {
  name: "PHANTOM WARRIORS",
  tagline: "PLAY. FIGHT. WIN.",
  game: "Free Fire",
  social: { discord: "", youtube: "", instagram: "" }, // fill in later
  images: { logo: "assets/images/logo/", backgrounds: "assets/images/backgrounds/" }
};
