# Project Status — PHANTOM WARRIORS

**Current batch:** 1A (foundation) — complete
**Next batch:** 1B — see `docs/NEXT_BATCH.md`

## Rules (mandatory)
HTML5, CSS3, vanilla JS only. No React, TypeScript, Node, npm, Tailwind, Bootstrap, or build tools. Must work by opening `index.html`.

## Brand
Near-black/charcoal backgrounds, metallic silver, crimson red (primary accent), restrained electric-blue lighting, premium cinematic esports look. Tagline: PLAY. FIGHT. WIN.

## Done in 1A
- All 7 pages with shared nav, footer, correct relative links
- Design tokens in `assets/css/style.css` (`:root`)
- Reusable components in `components.css`; mobile menu in `navigation.js`
- Site settings in `assets/js/config.js`
- Minimal hero on `index.html`; other pages are placeholders

## Not done
- No reference images imported (none were available in the working folder)
- No logo, real content, teams, maps, forms, map editor, or authentication
- Login page is a placeholder only
- Not tested on real mobile devices or multiple browsers

## Conventions
- Pages share identical header/footer markup; update all 7 when changing nav
- Colors/fonts via CSS variables only
- Fonts are system stacks (works offline)
