# PHANTOM WARRIORS — Free Fire esports website

Static site: HTML5, CSS3, vanilla JavaScript only. No build step.

## Open it
Unzip, then double-click `index.html` (or open it in any modern browser).

## Structure
- 7 pages in the root: index, about, teams, maps, plan-maps, contact, login
- `assets/css/` style (tokens, base), components, responsive
- `assets/js/` config (site settings), navigation (menu), main (shared setup)
- `docs/` roadmap, asset guide, next-batch brief

## Images
No reference images are included. See `docs/ASSET_GUIDE.md` for where to place them.

## Status
See `PROJECT_STATUS.md`.
